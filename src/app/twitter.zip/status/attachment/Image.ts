import {Attachment} from './Attachment';

export class Image extends Attachment {
  constructor(src: string) {
    super(src);
  }
}
