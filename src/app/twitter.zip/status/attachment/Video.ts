import {Attachment} from './Attachment';

export class Video extends Attachment {
  constructor(src: string) {
    super(src);
  }
}
